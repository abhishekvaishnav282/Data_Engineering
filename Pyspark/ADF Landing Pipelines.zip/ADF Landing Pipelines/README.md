# ADF pipelines to the ADLS Gen2 landing zone

Use the existing factory `adf-retail-de-261118` in `rg-retail-de-dev` and the `landing` container on the hierarchical-namespace account `stretailde26111701`. The Azure Blob connector writes to that same ADLS Gen2 account through its Blob endpoint. The five pipelines can be added and run independently after their dependencies are in place.

## One-by-one authoring order

1. Start with the [Video 11 package](../ADF%20Video%2011%20-%20Product%20Catalog%20REST/README.md). Add its numbered files 01–06 in order. Files 01 and 02 are shared by later pipelines.
2. Configure the private SQL runtime and network connections below. Add files 07–11 for SQL POS.
3. Add files 12–14 for warehouse Blob inventory.
4. Add files 15–18 for supplier SFTP.
5. Add files 19–22 for Cosmos DB CRM.

Use the matching artifact's **Code ({})** editor in ADF Studio. Create the linked service with its connector type and the dataset with its connector and format first. Apply each named JSON object, test the connection, then publish. These are individual definitions for Studio authoring, not a factory ARM template. The networking JSON has the property values for setting up those resources in **Manage**.

| Source | Files | Verify after running |
|---|---|---|
| Product Catalog REST | 01–06 | `landing/product-catalog/rest/products.json` contains `P001` and `P002`. |
| Azure SQL POS | 07–11 | Three CSVs under `landing/pos/azure-sql/<table>/<batchId>/`. The seeded full window returns `O001` and `O002` plus their matching items and payments. |
| Warehouse Blob | 12–14 | `landing/warehouse-inventory/blob/inventory-2026-11-16.csv` matches the source. |
| Supplier SFTP | 15–18 | `landing/supplier-erp/sftp/purchase-orders-2026-11-16.csv` matches the source. Run it again and verify that the Copy activity is skipped. |
| Cosmos DB CRM | 19–22 | `landing/crm/cosmos/batch-02/customers.json` contains `C001` in Mumbai if the source is still in the Video 8 state. |

## Permissions and connectivity

- **Common sink:** Grant the factory's system-assigned managed identity **Storage Blob Data Contributor** on `landing`.
- **Catalog and SFTP:** Grant that identity **Key Vault Secrets User** on `kv-retail-de-261118`. Recover or recreate `retail-catalog-function-key` with the current function key. Recreate the read/list-only `supplieradf` SFTP identity for `supplier-erp` and store the matching Base64-encoded PEM private key in `retail-supplier-adf-ssh-key`. An old key is usable only if it matches a public key configured for that local user. The linked service pins the host key observed in the earlier lab. Before testing, verify the currently presented fingerprint against Microsoft's published key for the storage region and update the file if it rotated. [Microsoft SFTP host keys](https://learn.microsoft.com/en-us/azure/storage/blobs/secure-file-transfer-protocol-host-keys)
- **Warehouse:** Grant **Storage Blob Data Reader** to the factory identity on `warehouse-inventory`.
- **Cosmos DB:** Assign the factory identity **Cosmos DB Built-in Data Reader** on `/dbs/retail-crm/colls/customers` using Cosmos DB data-plane RBAC.
- **Private SQL:** In ADF Studio, create an Azure integration runtime named `ir_retail_sql_private` with Managed Virtual Network enabled. Create and approve managed private endpoints to the POS SQL server and the storage account's Blob subresource. The SQL and POS sink linked services both use this runtime. Use an authorized session with private SQL connectivity to run the existing `Video 04 - Retail POS.sql` script on a fresh database and then run `SQL prerequisites/grant-adf-pos-read.sql`. The earlier SQL server had public access disabled, so the standard public runtime does not provide the required SQL route. [ADF managed virtual networks and private endpoints](https://learn.microsoft.com/en-us/azure/data-factory/managed-virtual-network-private-endpoint)

## Run parameters and limits

- **SQL POS:** Use a new `batchId` for each logical delivery. The three copies share a UTC window `(fromUtc, toUtc]`. To rerun the batch-02 fixture, use `fromUtc=2026-11-15T09:05:00Z`, `toUtc=2026-11-16T09:05:00Z`, and `batchId=batch-02`. Expect only order `O002` and its item and payment. Child rows follow the parent order watermark. Independent child edits or deletes are outside this fixture and require their own timestamps or CDC. These are three independent Copy activities. Check that all three succeeded before consuming a batch.
- **Warehouse and SFTP:** Pass the exact dated CSV basename as `fileName`. Warehouse copies the file as-is. SFTP treats an existing destination filename as already processed, so send a new filename for a corrected delivery.
- **Cosmos DB:** Supply UTC timestamps in the same `(fromUtc, toUtc]` pattern and a `batchId`. The default window uses the batch-01 timestamp as its lower bound. The query reads current documents and does not reconstruct historical versions or emit deletes.
- These templates use caller-supplied watermarks and manual runs. They do not update a watermark table or create schedules. Run twice with the same SQL or Cosmos batch ID only if you intend to rewrite that batch.

The files are offline artifacts. Azure authorization, network approvals, secret recovery, live connection tests, and publishing still need to be performed.
