-- Run as an authorized Entra database administrator in sqldb-retail-pos.
IF DATABASE_PRINCIPAL_ID(N'adf-retail-de-261118') IS NULL
    CREATE USER [adf-retail-de-261118] FROM EXTERNAL PROVIDER;

GRANT SELECT ON OBJECT::dbo.orders TO [adf-retail-de-261118];
GRANT SELECT ON OBJECT::dbo.order_items TO [adf-retail-de-261118];
GRANT SELECT ON OBJECT::dbo.payments TO [adf-retail-de-261118];
