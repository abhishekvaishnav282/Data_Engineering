# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze — validate landed files and log to Azure SQL
# MAGIC Each selected feed is read from the same ADLS Gen2 landing container. Accepted rows keep their original payload and lineage. Rejected rows are stored with error codes. SQL receives one audit outcome per attempted feed. A failed validation blocks downstream processing by default.

# COMMAND ----------

# MAGIC %run ./00_retail_common

# COMMAND ----------

import csv
import io
from uuid import uuid4
from pyspark import StorageLevel

account = account_widget()
batch = safe_id(widget("batch_id", "retail-demo-20261116"), "batch_id")
as_of = utc_widget("batch_as_of_utc", "2026-11-16T23:59:59Z")
run_id = widget("adf_run_id", "manual")
attempt = str(uuid4())
scope = widget("sql_secret_scope", "retail-audit")
audit_server = widget("audit_sql_server", "sql-retail-pos-26111701.database.windows.net")
audit_database = widget("audit_sql_database", "sqldb-retail-pos")
fail_on_reject = widget("fail_on_reject", "true").lower()
if fail_on_reject not in {"true", "false"}:
    raise ValueError("fail_on_reject must be true or false")
if not re.fullmatch(r"[A-Za-z0-9.-]+", audit_server) or not re.fullmatch(r"[A-Za-z0-9_-]+", audit_database):
    raise ValueError("Invalid SQL audit hostname or database")
sources = {name: widget(f"{name}_path", spec["file"]) for name, spec in FEEDS.items()}
max_file_bytes = 32 * 1024 * 1024

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation rules
# MAGIC 1. Require an exact, nonempty landing file with the expected extension, within the lab's 32 MiB per-file limit.
# MAGIC 2. Parse CSV with exact headers, standard quotes and the right column count. Parse JSON as a top-level array of objects with exactly the contract fields and unique property names.
# MAGIC 3. Require every contract field, enforce integral counts, fixed-precision money, ISO dates, and UTC timestamps.
# MAGIC 4. Enforce positive order and supplier quantities, non-negative money and inventory, ISO-shaped currency codes, recognized order statuses, matching CRM keys, and order update time at or after creation time.
# MAGIC 5. Keep cross-feed join checks in Silver, where both current and prior batches are available.

# COMMAND ----------

record_type = T.ArrayType(T.StructType([
    T.StructField("raw_payload", T.StringType()),
    T.StructField("values", T.MapType(T.StringType(), T.StringType())),
    T.StructField("parse_error", T.StringType()),
]))


def parser(fmt, required):
    expected = set(required)

    def reject(payload, error):
        return (payload, {}, error)

    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON property")
            result[key] = value
        return result

    @F.udf(record_type)
    def parse(text):
        text = text.lstrip("\ufeff")
        if fmt == "csv":
            try:
                rows = csv.reader(io.StringIO(text, newline=""), strict=True)
                header = next(rows, [])
                if len(header) != len(required) or set(header) != expected:
                    return [reject(text, "INVALID_CSV_HEADER")]
                records = []
                for row in rows:
                    if not row:
                        continue
                    payload = json.dumps(row, ensure_ascii=False)
                    if len(row) != len(header):
                        records.append(reject(payload, "INVALID_CSV_COLUMN_COUNT"))
                    else:
                        records.append((payload, dict(zip(header, row)), None))
                return records
            except csv.Error:
                return [reject(text, "INVALID_CSV_SYNTAX")]
        try:
            values = json.loads(text, object_pairs_hook=unique_object, parse_float=str)
        except ValueError:
            return [reject(text, "INVALID_JSON_SYNTAX")]
        if not isinstance(values, list):
            return [reject(text, "EXPECTED_JSON_ARRAY")]
        result = []
        for row in values:
            payload = json.dumps(row, ensure_ascii=False)
            if not isinstance(row, dict) or set(row) != expected:
                result.append(reject(payload, "INVALID_JSON_FIELDS"))
            elif any(isinstance(v, (bool, list, dict)) for v in row.values()):
                result.append(reject(payload, "NON_SCALAR_JSON_FIELD"))
            else:
                result.append((payload, {k: None if v is None else str(v) for k, v in row.items()}, None))
        return result

    return parse


def validate(name, relative, spec):
    if (not re.fullmatch(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*", relative)
            or any(part in {".", ".."} for part in relative.split("/"))
            or not relative.endswith("." + spec["format"])):
        raise ValueError("Expected an exact relative landing filename")
    path = lake(account, "landing", relative)
    assets = (spark.read.format("binaryFile").load(path).select("length", "modificationTime")
              .limit(2).collect())
    if len(assets) != 1 or not 0 < assets[0].length <= max_file_bytes:
        raise ValueError("Landing file is absent, empty, or exceeds size limit")
    data = (spark.read.text(path, wholetext=True)
            .select(F.posexplode(parser(spec["format"], list(spec["fields"]))("value"))
                    .alias("_source_row", "parsed"))
            .select("_source_row", "parsed.*"))
    errors = [F.col("parse_error")]
    for field, kind in spec["fields"].items():
        raw = F.trim(F.col("values").getItem(field))
        valid = raw.isNotNull() & (F.length(raw) > 0)
        if kind == "int":
            valid = valid & raw.rlike(r"^-?[0-9]+$")
        elif kind.startswith("decimal"):
            valid = valid & raw.rlike(r"^-?[0-9]+(\.[0-9]{1,2})?$")
        elif kind == "date":
            valid = valid & raw.rlike(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
        elif kind == "timestamp":
            valid = valid & raw.rlike(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?(Z|\+00:00)$")
        data = data.withColumn(field, F.when(valid, F.expr(f"try_cast(trim(values['{field}']) AS {kind})")))
        errors.append(F.when(F.col(field).isNull(), F.lit(f"INVALID_{field.upper()}")))

    for field, minimum in {"quantity": 1, "on_hand": 0, "price": 0, "unit_price": 0, "amount": 0}.items():
        if field in spec["fields"]:
            errors.append(F.when(F.col(field) < minimum, F.lit(f"OUT_OF_RANGE_{field.upper()}")))
    if "currency" in spec["fields"]:
        errors.append(F.when(~F.upper("currency").rlike("^[A-Z]{3}$"), F.lit("INVALID_CURRENCY_CODE")))
    if name == "orders":
        allowed = ["completed", "pending", "cancelled", "canceled", "refunded", "returned"]
        errors.extend([
            F.when(~F.lower("status").isin(allowed), F.lit("UNKNOWN_ORDER_STATUS")),
            F.when(F.col("updated_at") < F.col("order_timestamp"), F.lit("UPDATE_BEFORE_ORDER")),
        ])
    if name == "customers":
        errors.append(F.when(F.upper("id") != F.upper("customer_id"), F.lit("CRM_ID_MISMATCH")))

    row_errors = F.filter(F.array(*errors), lambda error: error.isNotNull())
    return (data.withColumn("_errors", F.when(F.col("parse_error").isNotNull(), F.array("parse_error"))
                            .otherwise(row_errors))
            .drop("parse_error", "values")
            .withColumn("_source_file", F.lit(relative))
            .withColumn("_source_modified_at", F.lit(assets[0].modificationTime).cast("timestamp"))
            .withColumn("_batch_id", F.lit(batch))
            .withColumn("_batch_as_of_utc", F.lit(as_of).cast("timestamp"))
            .withColumn("_adf_run_id", F.lit(run_id))
            .withColumn("_ingested_at", F.current_timestamp()))

# COMMAND ----------

audit_schema = """
    attempt_id string, adf_run_id string, batch_id string, source_name string, source_file string,
    status string, input_rows long, accepted_rows long, rejected_rows long,
    error_summary string, batch_as_of_utc timestamp, logged_at_utc timestamp
"""
outcomes = []
selected_sources = {name: relative for name, relative in sources.items() if relative}
if not selected_sources:
    raise ValueError("Select at least one landing path")
manifest_path = lake(account, "bronze", "retail/_manifest")
pending = [(attempt, run_id, batch, name, relative[:1024], "FAILED", None, None,
            None, "Bronze attempt is incomplete", as_of, datetime.now(timezone.utc))
           for name, relative in selected_sources.items()]
pending_manifest = (spark.createDataFrame(pending, audit_schema)
                    .withColumnRenamed("batch_id", "_batch_id")
                    .withColumn("allow_rejects", F.lit(False)))
replace_batch(pending_manifest, manifest_path, batch)
for name, relative in selected_sources.items():
    frame = None
    input_rows = accepted = rejected = None
    try:
        frame = validate(name, relative, FEEDS[name]).persist(StorageLevel.MEMORY_AND_DISK)
        counts = frame.agg(
            F.count("*").alias("total"),
            F.count(F.when(F.size("_errors") > 0, 1)).alias("rejected"),
        ).first()
        input_rows, rejected = counts.total, counts.rejected
        accepted = input_rows - rejected
        valid = F.size("_errors") == 0
        replace_batch(frame.where(valid).drop("_errors"), lake(account, "bronze", f"retail/{name}"), batch)
        replace_batch(frame.where(~valid), lake(account, "bronze", f"retail/quarantine/{name}"), batch)
        status = "REJECTED_ROWS" if rejected else "SUCCEEDED"
        summary = "See Bronze quarantine for row error codes" if rejected else None
    except Exception as error:
        status = "FAILED"
        summary = f"File validation or Delta write failed ({type(error).__name__})"
    finally:
        if frame is not None:
            frame.unpersist()
    outcomes.append((attempt, run_id, batch, name, relative[:1024], status, input_rows,
                     accepted, rejected, summary, as_of, datetime.now(timezone.utc)))

audit = spark.createDataFrame(outcomes, audit_schema)

# Use a dedicated SQL principal scoped to the audit table and Databricks secrets.
jdbc_url = (f"jdbc:sqlserver://{audit_server}:1433;databaseName={audit_database};"
            "encrypt=true;trustServerCertificate=false;loginTimeout=30;")
(audit.coalesce(1).write.format("jdbc").option("url", jdbc_url)
 .option("dbtable", "audit.bronze_validation_log")
 .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
 .option("user", dbutils.secrets.get(scope, "audit-sql-user"))
 .option("password", dbutils.secrets.get(scope, "audit-sql-password"))
 .mode("append").save())

manifest = audit.withColumnRenamed("batch_id", "_batch_id").withColumn(
    "allow_rejects", F.lit(fail_on_reject == "false"))
replace_batch(manifest, manifest_path, batch)
display(audit.drop("source_file"))

if any(row[5] == "FAILED" or (row[5] == "REJECTED_ROWS" and fail_on_reject == "true") for row in outcomes):
    raise RuntimeError(f"Bronze validation stopped batch {batch}. Check SQL audit and quarantine.")
