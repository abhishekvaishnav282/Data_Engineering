# Databricks notebook source
# MAGIC %md
# MAGIC # Gold — dimensions, facts and reporting marts
# MAGIC Read the enriched Silver tables. Publish current dimensions, facts at explicit business grains, and daily dashboards in Delta. Keep measures in their original currencies.

# COMMAND ----------

# MAGIC %run ./00_retail_common

# COMMAND ----------

account = account_widget()
batch = safe_id(widget("batch_id", "retail-demo-20261116"), "batch_id")
manifest = read_delta(lake(account, "silver", "retail/_manifest"))
if not manifest.where((F.col("_batch_id") == batch) & (F.col("status") == "SUCCEEDED")).take(1):
    raise RuntimeError(f"Batch {batch} has no successful Silver publication")


def silver(name, enriched=True):
    path = f"retail/enriched/{name}" if enriched else f"retail/{name}"
    return read_delta(lake(account, "silver", path))


def date_key(name):
    return F.date_format(F.col(name), "yyyyMMdd").cast("int")


orders = silver("orders")
items = silver("order_items")
payments = silver("payments")
inventory = silver("inventory")
purchases = silver("purchase_orders")
products = silver("products", enriched=False)
customers = silver("customers", enriched=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dimensions
# MAGIC Customer and product are current-state dimensions with deterministic keys. Supplier and warehouse dimensions contain the business IDs observed in their feeds. The date dimension includes every day between the first and last observed business date.

# COMMAND ----------

dim_customer = customers.select("customer_key", "customer_id", "name", "city", "updated_at")
dim_product = products.select("product_key", "product_id", "name", "category", "price", "currency", "updated_at")
dim_supplier = purchases.select("supplier_id").distinct().withColumn("supplier_key", F.sha2("supplier_id", 256))
dim_warehouse = inventory.select("warehouse_id").distinct().withColumn("warehouse_key", F.sha2("warehouse_id", 256))
observed_dates = (
    orders.select(F.col("order_date").alias("day"))
    .unionByName(inventory.select(F.col("snapshot_date").alias("day")))
    .unionByName(purchases.select(F.col("purchase_date").alias("day")))
)
bounds = observed_dates.agg(F.min("day").alias("first_day"), F.max("day").alias("last_day"))
dim_date = (
    bounds.where(F.col("first_day").isNotNull())
    .select(F.explode(F.sequence("first_day", "last_day")).alias("date"))
    .select("date", date_key("date").alias("date_key"),
            F.year("date").alias("year"), F.quarter("date").alias("quarter"),
            F.month("date").alias("month"), F.dayofmonth("date").alias("day_of_month"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Facts
# MAGIC Join facts to dimensions on unique IDs. Preserve rows with late-arriving dimensions and keep their unresolved flags. Payment totals and sales lines are never directly joined to each other.

# COMMAND ----------

fact_order = (
    orders.join(dim_customer.select("customer_id", "customer_key"), "customer_id", "left")
    .withColumn("date_key", date_key("order_date"))
    .select("order_id", "customer_key", "customer_id", "date_key", "order_date", "order_timestamp",
            "status", "has_customer", "is_completed", "processing_seconds", "order_currency", "line_total",
            "payment_total", "reconciliation_status", "reconciliation_difference")
)
order_context = fact_order.select("order_id", "customer_key", "date_key", "order_date", "order_currency")
fact_sales_line = (
    items.join(order_context, "order_id", "left")
    .join(dim_product.select("product_id", "product_key"), "product_id", "left")
    .select("order_item_id", "order_id", "product_key", "product_id", "customer_key",
            "date_key", "order_currency", "quantity", "unit_price", "line_amount", "has_order", "has_product")
)
fact_payment = (
    payments.join(order_context.select("order_id", "customer_key", "date_key"), "order_id", "left")
    .select("payment_id", "order_id", "customer_key", "date_key", "amount", "currency", "method", "has_order")
)
fact_inventory = (
    inventory.join(dim_warehouse, "warehouse_id", "left")
    .join(dim_product.select("product_id", "product_key"), "product_id", "left")
    .withColumn("date_key", date_key("snapshot_date"))
    .select("warehouse_key", "warehouse_id", "product_key", "product_id", "snapshot_date",
            "date_key", "on_hand", "stock_status", "has_product")
)
fact_purchase = (
    purchases.join(dim_supplier, "supplier_id", "left")
    .join(dim_product.select("product_id", "product_key"), "product_id", "left")
    .withColumn("date_key", date_key("purchase_date"))
    .select("purchase_order_id", "supplier_key", "supplier_id", "product_key", "product_id",
            "purchase_date", "date_key", "quantity", "has_product")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Daily marts
# MAGIC Sales groups completed orders by UTC date and currency. Orders with unresolved currency remain visible in the quality mart. Inventory sums same-day snapshots across warehouse/product keys.

# COMMAND ----------

mart_sales_daily = (
    fact_order.where(F.col("is_completed") & F.col("order_currency").isNotNull())
    .groupBy("order_date", "order_currency")
    .agg(F.count("*").alias("completed_orders"),
         F.sum("line_total").alias("sales_amount"),
         F.sum("payment_total").alias("payments_received"),
         F.count(F.when(F.col("reconciliation_status") != "MATCHED", 1)).alias("orders_needing_review"))
)
mart_inventory_daily = (
    fact_inventory.groupBy("snapshot_date", "product_id")
    .agg(F.sum("on_hand").alias("units_on_hand"),
         F.countDistinct("warehouse_id").alias("warehouses_reporting"),
         F.count(F.when(F.col("stock_status") == "OUT_OF_STOCK", 1)).alias("warehouses_out_of_stock"))
)
mart_order_quality_daily = (
    fact_order.groupBy("order_date", "reconciliation_status")
    .agg(F.count("*").alias("orders"),
         F.count(F.when(~F.col("has_customer"), 1)).alias("orders_missing_customer"))
)

# COMMAND ----------

published = {
    "dim_customer": (dim_customer, ["customer_key"]),
    "dim_product": (dim_product, ["product_key"]),
    "dim_supplier": (dim_supplier, ["supplier_key"]),
    "dim_warehouse": (dim_warehouse, ["warehouse_key"]),
    "dim_date": (dim_date, ["date_key"]),
    "fact_order": (fact_order, ["order_id"]),
    "fact_sales_line": (fact_sales_line, ["order_item_id"]),
    "fact_payment": (fact_payment, ["payment_id"]),
    "fact_inventory": (fact_inventory, ["warehouse_id", "product_id", "snapshot_date"]),
    "fact_purchase": (fact_purchase, ["purchase_order_id"]),
    "mart_sales_daily": (mart_sales_daily, ["order_date", "order_currency"]),
    "mart_inventory_daily": (mart_inventory_daily, ["snapshot_date", "product_id"]),
    "mart_order_quality_daily": (mart_order_quality_daily, ["order_date", "reconciliation_status"]),
}
for name, (frame, keys) in published.items():
    assert_unique(frame, keys, f"Gold {name}")
versions = {}
for name, (frame, _) in published.items():
    path = lake(account, "gold", f"retail/{name}")
    (frame.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .save(path))
    versions[name] = DeltaTable.forPath(spark, path).history(1).select("version").first().version

gold_manifest = spark.createDataFrame(
    [(batch, datetime.now(timezone.utc), len(published), json.dumps(versions, sort_keys=True))],
    "_batch_id string, published_at_utc timestamp, table_count int, table_versions string",
)
replace_batch(gold_manifest, lake(account, "gold", "retail/_manifest"), batch)
display(read_delta(lake(account, "gold", "retail/mart_sales_daily")).orderBy("order_date", "order_currency"))
