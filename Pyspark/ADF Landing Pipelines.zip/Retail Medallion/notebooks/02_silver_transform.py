# Databricks notebook source
# MAGIC %md
# MAGIC # Silver — 30 retail transformations
# MAGIC Run after Bronze completes. Each section describes the rule, its purpose, and what changes in the data.

# COMMAND ----------

# MAGIC %run ./00_retail_common

# COMMAND ----------

account = account_widget()
batch = safe_id(widget("batch_id", "retail-demo-20261116"), "batch_id")
manifest = (read_delta(lake(account, "bronze", "retail/_manifest"))
            .where(F.col("_batch_id") == batch).collect())
if not manifest or any(row.status == "FAILED" or
                       (row.status == "REJECTED_ROWS" and not row.allow_rejects) for row in manifest):
    raise RuntimeError(f"Batch {batch} has no accepted Bronze manifest")

selected = {row.source_name for row in manifest}
missing = [name for name in FEEDS if name not in selected and
           not DeltaTable.isDeltaTable(spark, lake(account, "silver", f"retail/{name}"))]
if missing:
    raise RuntimeError(f"The first Silver run needs all feeds. Missing: {missing}")
frames = {name: read_delta(lake(account, "bronze", f"retail/{name}"))
          .where(F.col("_batch_id") == batch) for name in FEEDS if name in selected}
silver_manifest_path = lake(account, "silver", "retail/_manifest")
silver_manifest_schema = "_batch_id string, published_at_utc timestamp, status string"
replace_batch(
    spark.createDataFrame([(batch, None, "IN_PROGRESS")], silver_manifest_schema),
    silver_manifest_path, batch,
)


def edit(feed, column, expression):
    if feed in frames:
        frames[feed] = frames[feed].withColumn(column, expression)


def flag(facts, dimension, key, name):
    return facts.join(dimension.select(key).distinct().withColumn(name, F.lit(True)), key, "left").fillna(
        False, subset=[name])

# COMMAND ----------

# MAGIC %md
# MAGIC ## 01. Trim text fields
# MAGIC Remove leading and trailing whitespace from IDs, names, statuses, and currency codes. This stops a trailing space from splitting a business key.

# COMMAND ----------

for name in frames:
    for column, kind in FEEDS[name]['fields'].items():
        if kind == 'string':
            frames[name] = frames[name].withColumn(column, F.trim(F.col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 02. Normalize empty strings
# MAGIC Turn whitespace-only text into null. Bronze already rejects missing required fields. This also keeps optional text added to a future contract consistent.

# COMMAND ----------

for name in frames:
    for column, kind in FEEDS[name]['fields'].items():
        if kind == 'string':
            frames[name] = frames[name].withColumn(column, F.when(F.length(column) > 0, F.col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 03. Canonicalize business IDs
# MAGIC Uppercase all business IDs across the feeds so the same customer, product, order, or supplier joins consistently regardless of input case.

# COMMAND ----------

for name in frames:
    for column in FEEDS[name]['fields']:
        if column == 'id' or column.endswith('_id'):
            frames[name] = frames[name].withColumn(column, F.upper(column))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 04. Standardize order status
# MAGIC Convert order statuses to lowercase and map the spelling canceled to cancelled. This gives downstream filters a single value for canceled orders.

# COMMAND ----------

if 'orders' in frames:
    status = F.lower('status')
    edit('orders', 'status', F.when(status == 'canceled', 'cancelled').otherwise(status))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 05. Normalize payment methods
# MAGIC Lowercase payment methods and collapse runs of spaces or hyphens into underscores. Payment grouping uses the normalized code.

# COMMAND ----------

edit('payments', 'method', F.regexp_replace(F.lower('method'), r'[\s-]+', '_'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 06. Normalize currencies
# MAGIC Uppercase currency codes in catalog and payments. No currency conversion is performed. Gold reports amounts by order currency derived from the payment data.

# COMMAND ----------

for name in ('payments', 'products'):
    edit(name, 'currency', F.upper('currency'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 07. Clean product names
# MAGIC Collapse repeated internal whitespace while preserving display capitalization and punctuation. This avoids changing the meaning of a product name.

# COMMAND ----------

edit('products', 'name', F.regexp_replace('name', r'\s+', ' '))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 08. Format product categories
# MAGIC Collapse repeated spaces and title-case the category label. Category grouping follows this canonical label.

# COMMAND ----------

edit('products', 'category', F.initcap(F.regexp_replace('category', r'\s+', ' ')))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 09. Clean customer names
# MAGIC Collapse repeated whitespace while preserving the customer's supplied capitalization. This normalized value is retained in the customer dimension.

# COMMAND ----------

edit('customers', 'name', F.regexp_replace('name', r'\s+', ' '))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Standardize customer city
# MAGIC Collapse repeated spaces and title-case the city. The sample update becomes Mumbai consistently across reporting.

# COMMAND ----------

edit('customers', 'city', F.initcap(F.regexp_replace('city', r'\s+', ' ')))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. Derive order date
# MAGIC Extract the calendar date from the already validated UTC order timestamp. This date drives daily sales reporting.

# COMMAND ----------

edit('orders', 'order_date', F.to_date('order_timestamp'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Derive order hour
# MAGIC Extract the UTC hour of the order timestamp. Keeping it as an integer allows hour-of-day reporting without parsing a timestamp again.

# COMMAND ----------

edit('orders', 'order_hour_utc', F.hour('order_timestamp'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 13. Derive source update date
# MAGIC Extract the calendar date of each available source update timestamp for orders, catalog, supplier and CRM. This gives a consistent audit-friendly date for change analysis.

# COMMAND ----------

for name in ('orders', 'products', 'purchase_orders', 'customers'):
    edit(name, 'source_update_date', F.to_date('updated_at'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 14. Choose the business version timestamp
# MAGIC Use updated_at where the source provides it. Use the orchestrator's batch-as-of timestamp for order lines, payments, and inventory, whose fixture contracts do not contain update timestamps. Replay an older batch with its original as-of time.

# COMMAND ----------

for name in frames:
    time_column = 'updated_at' if 'updated_at' in FEEDS[name]['fields'] else '_batch_as_of_utc'
    frames[name] = frames[name].withColumn('_version_ts', F.col(time_column))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 15. Fingerprint canonical payloads
# MAGIC Hash the ordered, normalized business columns with SHA-256. The hash keeps tie-breaking deterministic and excludes file paths and run metadata.

# COMMAND ----------

for name in frames:
    payload = F.to_json(F.struct(*FEEDS[name]['fields']), options={'ignoreNullFields': 'false'})
    frames[name] = frames[name].withColumn('_record_hash', F.sha2(payload, 256))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 16. Drop equivalent duplicates
# MAGIC Within each business key and version, keep the copy with a deterministic lineage order. This removes repeats without discarding newer versions.

# COMMAND ----------

for name in frames:
    keys = FEEDS[name]['keys'] + ['_version_ts', '_record_hash']
    rank = Window.partitionBy(*keys).orderBy('_source_file', '_source_row')
    frames[name] = frames[name].withColumn('_rank', F.row_number().over(rank)).where('_rank = 1').drop('_rank')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 17. Keep one latest candidate per key
# MAGIC Order each key by source version and then payload hash. This resolves differing same-time values reproducibly. It is a technical tie-break, not a claim about which record happened later.

# COMMAND ----------

for name in frames:
    rank = Window.partitionBy(*FEEDS[name]['keys']).orderBy(F.desc('_version_ts'), F.desc('_record_hash'))
    frames[name] = frames[name].withColumn('_rank', F.row_number().over(rank)).where('_rank = 1').drop('_rank')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 18. Calculate line amounts
# MAGIC Multiply validated quantity by fixed-precision unit price and store the result in a wider fixed-precision decimal. Gold uses this actual transaction amount rather than the current catalog price.

# COMMAND ----------

edit('order_items', 'line_amount', (F.col('quantity') * F.col('unit_price')).cast('decimal(29,2)'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 19. Calculate order processing lag
# MAGIC Subtract order creation from last update in seconds. Bronze ensures that this value cannot be negative.

# COMMAND ----------

edit('orders', 'processing_seconds', F.unix_timestamp('updated_at') - F.unix_timestamp('order_timestamp'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 20. Mark completed orders
# MAGIC Create a boolean flag for the normalized completed status. Gold's completed sales metric uses this flag while retaining other order statuses in the facts.

# COMMAND ----------

edit('orders', 'is_completed', F.col('status') == 'completed')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 21. Label inventory availability
# MAGIC Flag inventory as IN_STOCK or OUT_OF_STOCK based on its non-negative on-hand quantity. The daily snapshot grain remains warehouse, product, and date.

# COMMAND ----------

edit('inventory', 'stock_status', F.when(F.col('on_hand') > 0, 'IN_STOCK').otherwise('OUT_OF_STOCK'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 22. Derive purchase order date
# MAGIC Use the supplier snapshot's UTC update date as the reporting date. The fixture has no separate purchase-order creation timestamp.

# COMMAND ----------

edit('purchase_orders', 'purchase_date', F.to_date('updated_at'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 23. Create stable business-key surrogate IDs
# MAGIC Create deterministic SHA-256 keys for customers and products. The same source key maps to the same dimension key on every retry.

# COMMAND ----------

for name, key in [('customers', 'customer_id'), ('products', 'product_id')]:
    edit(name, key.replace('_id', '_key'), F.sha2(F.col(key), 256))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 24. Merge versioned Silver records
# MAGIC Merge the deduplicated candidates into Delta on their business key. An older replay cannot replace a newer row. Inventory retains the snapshot date as part of its key.

# COMMAND ----------

for name, incoming in frames.items():
    path = lake(account, 'silver', f'retail/{name}')
    keys = FEEDS[name]['keys']
    if DeltaTable.isDeltaTable(spark, path):
        on = ' AND '.join(f't.{key} = s.{key}' for key in keys)
        fresher = ('s._version_ts > t._version_ts OR '
                   '(s._version_ts = t._version_ts AND s._record_hash > t._record_hash)')
        (DeltaTable.forPath(spark, path).alias('t').merge(incoming.alias('s'), on)
         .whenMatchedUpdateAll(condition=fresher).whenNotMatchedInsertAll().execute())
    else:
        incoming.write.format('delta').mode('errorifexists').save(path)
current = {n: read_delta(lake(account, 'silver', f'retail/{n}')) for n in FEEDS}

# COMMAND ----------

# MAGIC %md
# MAGIC ## 25. Check order-to-customer relationships
# MAGIC Left-join the current order set to customer keys. Keep unmatched orders and mark them so a late-arriving customer does not drop transaction facts.

# COMMAND ----------

orders = flag(current['orders'], current['customers'], 'customer_id', 'has_customer')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 26. Check order-item relationships
# MAGIC Check each line against both the order and product dimensions. Separate flags distinguish missing orders from missing product details.

# COMMAND ----------

items = flag(current['order_items'], current['orders'], 'order_id', 'has_order')
items = flag(items, current['products'], 'product_id', 'has_product')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 27. Check payment-to-order relationships
# MAGIC Mark payments whose order is present. Use the complete current Silver state so parents from an earlier batch are still recognized.

# COMMAND ----------

payments = flag(current['payments'], current['orders'], 'order_id', 'has_order')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 28. Check inventory-to-product relationships
# MAGIC Retain stock snapshots with missing product details and flag the unresolved reference. This preserves operational stock counts.

# COMMAND ----------

inventory = flag(current['inventory'], current['products'], 'product_id', 'has_product')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 29. Check supplier purchase product relationships
# MAGIC Flag purchase orders with no product match. Supplier IDs come from purchase records themselves because the project has no separate supplier master.

# COMMAND ----------

purchases = flag(current['purchase_orders'], current['products'], 'product_id', 'has_product')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 30. Reconcile orders to payments
# MAGIC Aggregate lines and payments separately at order grain before joining to avoid line-by-payment multiplication. Classify missing, mixed-currency, matched, and mismatched totals. Keep unknown currencies out of completed sales KPIs in Gold.

# COMMAND ----------

line_totals = current['order_items'].groupBy('order_id').agg(F.sum('line_amount').alias('line_total'))
paid_totals = current['payments'].groupBy('order_id').agg(
    F.sum('amount').alias('payment_total'),
    F.countDistinct('currency').alias('payment_currencies'),
    F.min('currency').alias('order_currency'),
)
orders = (orders.join(line_totals, 'order_id', 'left').join(paid_totals, 'order_id', 'left')
          .withColumn('reconciliation_status',
                      F.when(F.col('line_total').isNull(), 'MISSING_LINES')
                       .when(F.col('payment_total').isNull(), 'MISSING_PAYMENT')
                       .when(F.col('payment_currencies') != 1, 'MIXED_CURRENCY')
                       .when(F.col('line_total') == F.col('payment_total'), 'MATCHED')
                       .otherwise('MISMATCH'))
          .withColumn('order_currency', F.when(F.col('payment_currencies') == 1, F.col('order_currency')))
          .withColumn('reconciliation_difference',
                      F.when(F.col('payment_currencies') == 1, F.col('line_total') - F.col('payment_total'))))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Publish reporting-ready Silver datasets
# MAGIC Recompute relationship flags and reconciliation from the merged current state, so a later dimension arrival can repair earlier missing references.

# COMMAND ----------

for name, frame in {"orders": orders, "order_items": items, "payments": payments,
                    "inventory": inventory, "purchase_orders": purchases}.items():
    assert_unique(frame, FEEDS[name]["keys"], f"Silver {name}")
    (frame.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .save(lake(account, "silver", f"retail/enriched/{name}")))

silver_manifest = spark.createDataFrame([(batch, datetime.now(timezone.utc), "SUCCEEDED")],
                                       silver_manifest_schema)
replace_batch(silver_manifest, silver_manifest_path, batch)
display(orders.groupBy("reconciliation_status").count())
