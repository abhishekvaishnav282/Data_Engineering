# Databricks notebook source
# MAGIC %md
# MAGIC # Shared retail configuration
# MAGIC Import this source notebook with the three stage notebooks into the same workspace directory.

# COMMAND ----------

import json
import re
from datetime import datetime, timezone

from delta.tables import DeltaTable
from pyspark.sql import Window, functions as F, types as T

spark.conf.set("spark.sql.session.timeZone", "UTC")

DEFAULT_ACCOUNT = "stretailde26111701"

FEEDS = {
    "orders": {
        "file": "pos/azure-sql/orders/pos-full-demo/orders.csv", "format": "csv",
        "keys": ["order_id"],
        "fields": {"order_id": "string", "customer_id": "string", "order_timestamp": "timestamp",
                   "updated_at": "timestamp", "status": "string"},
    },
    "order_items": {
        "file": "pos/azure-sql/order_items/pos-full-demo/order_items.csv", "format": "csv",
        "keys": ["order_item_id"],
        "fields": {"order_item_id": "string", "order_id": "string", "product_id": "string",
                   "quantity": "int", "unit_price": "decimal(18,2)"},
    },
    "payments": {
        "file": "pos/azure-sql/payments/pos-full-demo/payments.csv", "format": "csv",
        "keys": ["payment_id"],
        "fields": {"payment_id": "string", "order_id": "string", "amount": "decimal(18,2)",
                   "currency": "string", "method": "string"},
    },
    "products": {
        "file": "product-catalog/rest/products.json", "format": "json", "keys": ["product_id"],
        "fields": {"product_id": "string", "category": "string", "name": "string",
                   "price": "decimal(18,2)", "currency": "string", "updated_at": "timestamp"},
    },
    "inventory": {
        "file": "warehouse-inventory/blob/inventory-2026-11-16.csv", "format": "csv",
        "keys": ["warehouse_id", "product_id", "snapshot_date"],
        "fields": {"warehouse_id": "string", "product_id": "string", "on_hand": "int",
                   "snapshot_date": "date"},
    },
    "purchase_orders": {
        "file": "supplier-erp/sftp/purchase-orders-2026-11-16.csv", "format": "csv",
        "keys": ["purchase_order_id"],
        "fields": {"purchase_order_id": "string", "supplier_id": "string", "product_id": "string",
                   "quantity": "int", "updated_at": "timestamp"},
    },
    "customers": {
        "file": "crm/cosmos/batch-02/customers.json", "format": "json", "keys": ["customer_id"],
        "fields": {"id": "string", "customer_id": "string", "name": "string", "city": "string",
                   "updated_at": "timestamp"},
    },
}


def widget(name, default=""):
    dbutils.widgets.text(name, default)
    return dbutils.widgets.get(name).strip()


def safe_id(value, label):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}", value):
        raise ValueError(f"{label} must be 1–80 letters, digits, underscores, or hyphens")
    return value


def account_widget():
    account = widget("storage_account", DEFAULT_ACCOUNT)
    if not re.fullmatch(r"[a-z0-9]{3,24}", account):
        raise ValueError("Invalid ADLS Gen2 storage account")
    return account


def lake(account, container, path=""):
    return f"abfss://{container}@{account}.dfs.core.windows.net/{path}"


def utc_widget(name, default):
    text = widget(name, default)
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if value.tzinfo is None or value.utcoffset() != timezone.utc.utcoffset(value):
        raise ValueError(f"{name} must include UTC timezone Z or +00:00")
    return value.astimezone(timezone.utc)


def replace_batch(frame, path, batch_id):
    safe_id(batch_id, "batch_id")
    (frame.write.format("delta").mode("overwrite")
     .option("replaceWhere", f"_batch_id = '{batch_id}'").save(path))


def read_delta(path):
    return spark.read.format("delta").load(path)


def assert_unique(frame, keys, label):
    if frame.groupBy(*keys).count().where(F.col("count") > 1).limit(1).count():
        raise ValueError(f"{label} violates its grain: {keys}")
