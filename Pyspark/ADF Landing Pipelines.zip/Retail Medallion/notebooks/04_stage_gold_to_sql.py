# Databricks notebook source
# MAGIC %md
# MAGIC # Stage the published Gold snapshot for Azure SQL
# MAGIC This notebook pins one Delta version per Gold table. It stages data and a row-count manifest under a new publication ID. ADF calls the SQL publication procedure only after this job returns successfully.

# COMMAND ----------

# MAGIC %run ./00_retail_common

# COMMAND ----------

from uuid import uuid4

account = account_widget()
batch = safe_id(widget("batch_id", "retail-demo-20261116"), "batch_id")
scope = widget("report_secret_scope", "retail-report")
server = widget("report_sql_server", "sql-retail-pos-26111701.database.windows.net")
database = widget("report_sql_database", "sqldb-retail-pos")
if not re.fullmatch(r"[A-Za-z0-9.-]+", server) or not re.fullmatch(r"[A-Za-z0-9_-]+", database):
    raise ValueError("Invalid reporting SQL hostname or database")

names = [
    "dim_customer",
    "dim_product",
    "dim_supplier",
    "dim_warehouse",
    "dim_date",
    "fact_order",
    "fact_sales_line",
    "fact_payment",
    "fact_inventory",
    "fact_purchase",
    "mart_sales_daily",
    "mart_inventory_daily",
    "mart_order_quality_daily"
]
root = lake(account, "gold", "retail/")
pointer = (read_delta(root + "_manifest").orderBy(F.desc("published_at_utc")).first())
if pointer is None or pointer._batch_id != batch or pointer.table_count != len(names):
    raise RuntimeError(f"Batch {batch} is not the current complete Gold snapshot")

publication = str(uuid4())
versions = json.loads(pointer.table_versions)
if set(versions) != set(names) or any(type(v) is not int or v < 0 for v in versions.values()):
    raise RuntimeError("Gold manifest has invalid Delta versions")
# Spark returns collected timestamps as naive local datetimes. Pass the value back to Spark
# unchanged under the same process timezone, preserving the original timestamp.
snapshot_time = pointer.published_at_utc
jdbc_url = (f"jdbc:sqlserver://{server}:1433;databaseName={database};"
            "encrypt=true;trustServerCertificate=false;loginTimeout=30;")
user = dbutils.secrets.get(scope, "report-sql-user")
password = dbutils.secrets.get(scope, "report-sql-password")


def append_sql(frame, table):
    (frame.coalesce(1).write.format("jdbc").option("url", jdbc_url).option("dbtable", table)
     .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
     .option("user", user).option("password", password).mode("append").save())


manifest = []
for name in names:
    path = root + name
    snapshot = spark.read.format("delta").option("versionAsOf", versions[name]).load(path)
    rows = snapshot.select(
        F.lit(publication).alias("publication_id"),
        F.lit(name).alias("model_name"),
        F.to_json(F.struct(*snapshot.columns), {"ignoreNullFields": "false"}).alias("row_json"),
    )
    expected = rows.count()
    if expected:
        append_sql(rows, "report_stage.model_rows")
    manifest.append((publication, batch, name, expected, snapshot_time))

latest = read_delta(root + "_manifest").orderBy(F.desc("published_at_utc")).first()
if latest != pointer:
    raise RuntimeError("Gold was republished while this notebook was staging the snapshot")
append_sql(spark.createDataFrame(
    manifest, "publication_id string, batch_id string, model_name string, expected_rows long, staged_at_utc timestamp"
), "report_stage.model_manifest")
dbutils.notebook.exit(publication)
