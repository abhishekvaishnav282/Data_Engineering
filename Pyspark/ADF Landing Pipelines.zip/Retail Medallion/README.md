# Retail medallion on ADLS Gen2

This offline package adds three Databricks notebooks and four ADF pipelines to the five [landing pipelines](../ADF%20Landing%20Pipelines/README.md). All stages use `stretailde26111701`. Bronze reads the `landing` container and writes `bronze`. Silver reads Bronze and writes `silver`. Gold reads Silver and writes `gold`. SQL Server stores the Bronze audit log. The business datasets stay in ADLS Gen2.

| Stage | Notebook | Contents |
|---|---|---|
| Shared | `00_retail_common.py` | Landing contracts, widgets, UTC, ADLS paths, Delta batch utilities |
| Bronze | `01_bronze_validate_and_audit.py` | Seven feed contracts, accepted Delta rows, rejects with error codes, SQL audit and a batch manifest |
| Silver | `02_silver_transform.py` | 30 numbered transformations with an explanation next to each code cell, Delta merges, relationship flags and order/payment reconciliation |
| Gold | `03_gold_publish.py` | Five dimensions, five facts and three daily reporting marts, all as Delta tables |

## Prepare the workspace and SQL audit

1. Import the four `.py` files as Databricks source notebooks into `/Shared/retail-medallion`. Keep the base names without `.py`, because the notebooks reference the shared notebook by relative path. Use an existing Unity Catalog-capable Databricks cluster with a supported Databricks Runtime LTS, Delta Lake, Python UDF support, and the Microsoft SQL Server JDBC driver. Replace `REPLACE_WITH_DATABRICKS_CLUSTER_ID` in file 23.
2. Configure ADF's system-assigned managed identity for the Databricks linked service. The workspace/cluster must allow that identity to run the notebooks and access the required secret scope. Grant the notebook's execution identity read access on the landing external location and read/write access on the Bronze, Silver, and Gold external locations. All paths are direct `abfss://` paths. [ADF Databricks linked service](https://learn.microsoft.com/en-us/azure/data-factory/compute-linked-services#azure-databricks-linked-service) · [Unity Catalog privileges](https://learn.microsoft.com/en-us/azure/databricks/data-governance/unity-catalog/access-control/privileges-reference)
3. Run `sql/01-create-bronze-validation-log.sql` in the audit database. Create a dedicated SQL authentication user and add it to `bronze_audit_writer`. Create the Databricks secret scope `retail-audit` with keys `audit-sql-user` and `audit-sql-password`. Supply values through the secret manager. Grant the notebook execution identity permission to read only the required scope. If the deployment uses an Entra-only SQL server, configure an approved JDBC Entra authentication method before using the Bronze notebook. The included JDBC code uses a SQL authentication user.
4. Provide a network path and private DNS from the Databricks compute to the audit SQL server on 1433. The ADF managed private endpoint for the POS linked service is for the ADF runtime and does not give Databricks a SQL route. JDBC requires TLS with certificate validation.

## Add and run the ADF pipelines

Add landing artifacts 01–22 first, in the order in the [landing guide](../ADF%20Landing%20Pipelines/README.md). The POS orders query now serializes both timestamps as ISO-8601 UTC with a trailing `Z` so they match the Bronze contract. Then add these named artifacts in ADF Studio using each linked service or pipeline's JSON code editor.

| Order | Artifact | What it runs |
|---|---|---|
| 23 | `ls_retail_databricks_medallion` | Databricks workspace and existing cluster via the factory identity |
| 24 | `pl_retail_bronze` | Bronze validation and SQL log |
| 25 | `pl_retail_silver` | Silver transformations after a successful Bronze manifest exists |
| 26 | `pl_retail_gold` | Gold publication after a successful Silver manifest exists |
| 27 | `pl_retail_landing_to_gold` | Optional five landing pipelines, then Bronze → Silver → Gold |

The parent defaults to the five source-ingestion pipelines. Use `run_landing=false` only when the expected landing files already exist. The parent derives all seven paths from the same parameters sent to the ingestion jobs. If the files were landed under different names, use the Bronze wrapper and supply those paths explicitly. On a first Silver run, land all seven feeds. Later, use the Bronze wrapper with an empty path for any unchanged feed, then run the Silver and Gold wrappers with the same batch ID. Preserve the original UTC `batch_as_of_utc` when retrying a batch.

The default source inputs are the current catalog, both POS demo orders with their matching child rows, the November 16 inventory and supplier files, and the batch-02 CRM update. Bronze expects the *landing pipeline outputs*, including arrays for catalog and CRM, and the exact output names below.

| Feed | Default file below `landing/` |
|---|---|
| Orders | `pos/azure-sql/orders/pos-full-demo/orders.csv` |
| Order items | `pos/azure-sql/order_items/pos-full-demo/order_items.csv` |
| Payments | `pos/azure-sql/payments/pos-full-demo/payments.csv` |
| Product catalog | `product-catalog/rest/products.json` |
| Inventory | `warehouse-inventory/blob/inventory-2026-11-16.csv` |
| Supplier | `supplier-erp/sftp/purchase-orders-2026-11-16.csv` |
| Customers | `crm/cosmos/batch-02/customers.json` |

## Verify results

- In SQL, run `sql/02-query-bronze-validation-log.sql`. A clean default run should show seven successful feed outcomes, zero rejected rows, and eleven accepted rows if the seeded source data is intact. Bronze keeps original payloads in `bronze/retail/<feed>` and rejects in `bronze/retail/quarantine/<feed>`.
- In Silver, verify that orders `O001` and `O002` reconcile to 500 and 550 INR, respectively, and that customer `C001` is in Mumbai. The notebook explains the grain, normalization, deduplication, replay handling, derived fields, relationships and reconciliation next to their code.
- In Gold, check `gold/retail/mart_sales_daily` for INR sales of 500 on November 15 and 550 on November 16, and `gold/retail/mart_inventory_daily` for 100 units of `P001` on November 16. Gold uses the current Silver state, independent of which successful batch ID initiated publication.

## Replay and operating limits

- One file per feed per run, 32 MiB per file, for this training lab. Empty JSON arrays or header-only CSVs are accepted as zero-row extracts. A missing, zero-byte, or malformed file is logged as a failed or rejected source. The file-level or row-level reason determines whether details are available in quarantine.
- A normal rerun replaces the same Bronze batch in Delta. Audit rows intentionally retain separate attempts. Silver merges newer versions and retains prior state for feeds that were skipped. Gold rebuilds the current reporting tables. Retries can repeat writes, and there is no cross-table or cross-system transaction. The notebook manifests and ADF success dependencies identify completed stages. Run one batch at a time and avoid concurrent manual jobs or writes to these landing paths.
- Bronze fails on rejects by default after logging and quarantining. Set `fail_on_reject=false` only for an intentional partial acceptance. Restrict access to Bronze payloads and quarantine data because they contain original records.
- Watermark windows are caller-supplied. The pipeline has no scheduled triggers or automatic watermark advancement. No Azure import, infrastructure deployment, or live SQL/Databricks execution is part of this offline package.
