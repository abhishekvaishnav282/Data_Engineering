-- Set this to the batch_id supplied to the ADF medallion pipeline.
DECLARE @batch_id varchar(80) = 'retail-demo-20261116';
SELECT attempt_id, source_name, status, input_rows, accepted_rows, rejected_rows,
       error_summary, logged_at_utc
FROM audit.bronze_validation_log
WHERE batch_id = @batch_id
ORDER BY logged_at_utc DESC, source_name;
