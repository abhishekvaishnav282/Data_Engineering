-- Run in the Azure SQL audit database as an authorized database administrator.
IF SCHEMA_ID(N'audit') IS NULL
    EXEC(N'CREATE SCHEMA audit AUTHORIZATION dbo');

IF OBJECT_ID(N'audit.bronze_validation_log', N'U') IS NULL
BEGIN
    CREATE TABLE audit.bronze_validation_log
    (
        attempt_id varchar(36) NOT NULL,
        adf_run_id nvarchar(100) NOT NULL,
        batch_id varchar(80) NOT NULL,
        source_name varchar(40) NOT NULL,
        source_file nvarchar(1024) NOT NULL,
        status varchar(20) NOT NULL,
        input_rows bigint NULL,
        accepted_rows bigint NULL,
        rejected_rows bigint NULL,
        error_summary nvarchar(400) NULL,
        batch_as_of_utc datetime2(6) NOT NULL,
        logged_at_utc datetime2(6) NOT NULL,
        CONSTRAINT PK_bronze_validation_log PRIMARY KEY (attempt_id, source_name),
        CONSTRAINT CK_bronze_status CHECK (status IN ('SUCCEEDED', 'REJECTED_ROWS', 'FAILED')),
        CONSTRAINT CK_bronze_counts CHECK (
            (input_rows IS NULL AND accepted_rows IS NULL AND rejected_rows IS NULL)
            OR (input_rows >= 0 AND accepted_rows >= 0 AND rejected_rows >= 0
                AND input_rows = accepted_rows + rejected_rows)
        )
    );
    CREATE INDEX IX_bronze_validation_batch
        ON audit.bronze_validation_log (batch_id, logged_at_utc DESC, source_name);
END;

IF DATABASE_PRINCIPAL_ID(N'bronze_audit_writer') IS NULL
    CREATE ROLE bronze_audit_writer;

-- Spark JDBC needs SELECT on the target to inspect its schema when appending.
GRANT SELECT, INSERT ON OBJECT::audit.bronze_validation_log TO bronze_audit_writer;
-- Provision a dedicated database principal separately, then add it to this role.
-- Store that principal's credentials in the Databricks secret scope.
