-- Run in the Azure SQL reporting database with compatibility level 130 or higher.
SET XACT_ABORT ON;
IF SCHEMA_ID(N'report') IS NULL EXEC(N'CREATE SCHEMA report AUTHORIZATION dbo');
IF SCHEMA_ID(N'report_stage') IS NULL EXEC(N'CREATE SCHEMA report_stage AUTHORIZATION dbo');
IF OBJECT_ID(N'report_stage.model_rows', N'U') IS NULL
BEGIN
    CREATE TABLE report_stage.model_rows
    (
        publication_id varchar(36) NOT NULL,
        model_name varchar(64) NOT NULL,
        row_json nvarchar(max) NOT NULL,
        CONSTRAINT CK_report_stage_json CHECK (ISJSON(row_json) = 1)
    );
    CREATE INDEX IX_report_stage_rows ON report_stage.model_rows (publication_id, model_name);
END;
IF OBJECT_ID(N'report_stage.model_manifest', N'U') IS NULL
    CREATE TABLE report_stage.model_manifest
    (
        publication_id varchar(36) NOT NULL,
        batch_id varchar(80) NOT NULL,
        model_name varchar(64) NOT NULL,
        expected_rows bigint NOT NULL CHECK (expected_rows >= 0),
        staged_at_utc datetime2(6) NOT NULL,
        CONSTRAINT PK_report_stage_manifest PRIMARY KEY (publication_id, model_name)
    );
IF OBJECT_ID(N'report.publication_log', N'U') IS NULL
    CREATE TABLE report.publication_log
    (
        publication_id varchar(36) NOT NULL PRIMARY KEY,
        batch_id varchar(80) NOT NULL,
        staged_at_utc datetime2(6) NOT NULL,
        published_at_utc datetime2(6) NOT NULL
    );

IF OBJECT_ID(N'report.dim_customer', N'U') IS NULL
BEGIN
    CREATE TABLE report.dim_customer
    (
        [customer_key] char(64) NOT NULL,
        [customer_id] nvarchar(100) NOT NULL,
        [name] nvarchar(200) NOT NULL,
        [city] nvarchar(160) NOT NULL,
        [updated_at] datetimeoffset(6) NOT NULL,
        CONSTRAINT PK_dim_customer PRIMARY KEY ([customer_key])
    );
END;

IF OBJECT_ID(N'report.dim_product', N'U') IS NULL
BEGIN
    CREATE TABLE report.dim_product
    (
        [product_key] char(64) NOT NULL,
        [product_id] nvarchar(100) NOT NULL,
        [name] nvarchar(200) NOT NULL,
        [category] nvarchar(160) NOT NULL,
        [price] decimal(18,2) NOT NULL,
        [currency] char(3) NOT NULL,
        [updated_at] datetimeoffset(6) NOT NULL,
        CONSTRAINT PK_dim_product PRIMARY KEY ([product_key])
    );
END;

IF OBJECT_ID(N'report.dim_supplier', N'U') IS NULL
BEGIN
    CREATE TABLE report.dim_supplier
    (
        [supplier_id] nvarchar(100) NOT NULL,
        [supplier_key] char(64) NOT NULL,
        CONSTRAINT PK_dim_supplier PRIMARY KEY ([supplier_key])
    );
END;

IF OBJECT_ID(N'report.dim_warehouse', N'U') IS NULL
BEGIN
    CREATE TABLE report.dim_warehouse
    (
        [warehouse_id] nvarchar(100) NOT NULL,
        [warehouse_key] char(64) NOT NULL,
        CONSTRAINT PK_dim_warehouse PRIMARY KEY ([warehouse_key])
    );
END;

IF OBJECT_ID(N'report.dim_date', N'U') IS NULL
BEGIN
    CREATE TABLE report.dim_date
    (
        [date] date NOT NULL,
        [date_key] int NOT NULL,
        [year] int NOT NULL,
        [quarter] int NOT NULL,
        [month] int NOT NULL,
        [day_of_month] int NOT NULL,
        CONSTRAINT PK_dim_date PRIMARY KEY ([date_key])
    );
END;

IF OBJECT_ID(N'report.fact_order', N'U') IS NULL
BEGIN
    CREATE TABLE report.fact_order
    (
        [order_id] nvarchar(100) NOT NULL,
        [customer_key] char(64) NULL,
        [customer_id] nvarchar(100) NOT NULL,
        [date_key] int NOT NULL,
        [order_date] date NOT NULL,
        [order_timestamp] datetimeoffset(6) NOT NULL,
        [status] nvarchar(40) NOT NULL,
        [has_customer] bit NOT NULL,
        [is_completed] bit NOT NULL,
        [processing_seconds] bigint NOT NULL,
        [order_currency] char(3) NULL,
        [line_total] decimal(38,2) NULL,
        [payment_total] decimal(38,2) NULL,
        [reconciliation_status] nvarchar(40) NOT NULL,
        [reconciliation_difference] decimal(38,2) NULL,
        CONSTRAINT PK_fact_order PRIMARY KEY ([order_id])
    );
END;

IF OBJECT_ID(N'report.fact_sales_line', N'U') IS NULL
BEGIN
    CREATE TABLE report.fact_sales_line
    (
        [order_item_id] nvarchar(100) NOT NULL,
        [order_id] nvarchar(100) NOT NULL,
        [product_key] char(64) NULL,
        [product_id] nvarchar(100) NOT NULL,
        [customer_key] char(64) NULL,
        [date_key] int NULL,
        [order_currency] char(3) NULL,
        [quantity] int NOT NULL,
        [unit_price] decimal(18,2) NOT NULL,
        [line_amount] decimal(29,2) NOT NULL,
        [has_order] bit NOT NULL,
        [has_product] bit NOT NULL,
        CONSTRAINT PK_fact_sales_line PRIMARY KEY ([order_item_id])
    );
END;

IF OBJECT_ID(N'report.fact_payment', N'U') IS NULL
BEGIN
    CREATE TABLE report.fact_payment
    (
        [payment_id] nvarchar(100) NOT NULL,
        [order_id] nvarchar(100) NOT NULL,
        [customer_key] char(64) NULL,
        [date_key] int NULL,
        [amount] decimal(18,2) NOT NULL,
        [currency] char(3) NOT NULL,
        [method] nvarchar(100) NOT NULL,
        [has_order] bit NOT NULL,
        CONSTRAINT PK_fact_payment PRIMARY KEY ([payment_id])
    );
END;

IF OBJECT_ID(N'report.fact_inventory', N'U') IS NULL
BEGIN
    CREATE TABLE report.fact_inventory
    (
        [warehouse_key] char(64) NOT NULL,
        [warehouse_id] nvarchar(100) NOT NULL,
        [product_key] char(64) NULL,
        [product_id] nvarchar(100) NOT NULL,
        [snapshot_date] date NOT NULL,
        [date_key] int NOT NULL,
        [on_hand] int NOT NULL,
        [stock_status] nvarchar(30) NOT NULL,
        [has_product] bit NOT NULL,
        CONSTRAINT PK_fact_inventory PRIMARY KEY ([warehouse_id], [product_id], [snapshot_date])
    );
END;

IF OBJECT_ID(N'report.fact_purchase', N'U') IS NULL
BEGIN
    CREATE TABLE report.fact_purchase
    (
        [purchase_order_id] nvarchar(100) NOT NULL,
        [supplier_key] char(64) NOT NULL,
        [supplier_id] nvarchar(100) NOT NULL,
        [product_key] char(64) NULL,
        [product_id] nvarchar(100) NOT NULL,
        [purchase_date] date NOT NULL,
        [date_key] int NOT NULL,
        [quantity] int NOT NULL,
        [has_product] bit NOT NULL,
        CONSTRAINT PK_fact_purchase PRIMARY KEY ([purchase_order_id])
    );
END;

IF OBJECT_ID(N'report.mart_sales_daily', N'U') IS NULL
BEGIN
    CREATE TABLE report.mart_sales_daily
    (
        [order_date] date NOT NULL,
        [order_currency] char(3) NOT NULL,
        [completed_orders] bigint NOT NULL,
        [sales_amount] decimal(38,2) NULL,
        [payments_received] decimal(38,2) NULL,
        [orders_needing_review] bigint NOT NULL,
        CONSTRAINT PK_mart_sales_daily PRIMARY KEY ([order_date], [order_currency])
    );
END;

IF OBJECT_ID(N'report.mart_inventory_daily', N'U') IS NULL
BEGIN
    CREATE TABLE report.mart_inventory_daily
    (
        [snapshot_date] date NOT NULL,
        [product_id] nvarchar(100) NOT NULL,
        [units_on_hand] bigint NOT NULL,
        [warehouses_reporting] bigint NOT NULL,
        [warehouses_out_of_stock] bigint NOT NULL,
        CONSTRAINT PK_mart_inventory_daily PRIMARY KEY ([snapshot_date], [product_id])
    );
END;

IF OBJECT_ID(N'report.mart_order_quality_daily', N'U') IS NULL
BEGIN
    CREATE TABLE report.mart_order_quality_daily
    (
        [order_date] date NOT NULL,
        [reconciliation_status] nvarchar(40) NOT NULL,
        [orders] bigint NOT NULL,
        [orders_missing_customer] bigint NOT NULL,
        CONSTRAINT PK_mart_order_quality_daily PRIMARY KEY ([order_date], [reconciliation_status])
    );
END;
GO

CREATE OR ALTER PROCEDURE report.publish_gold
    @publication_id varchar(36)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF TRY_CONVERT(uniqueidentifier, @publication_id) IS NULL
        THROW 51000, 'Invalid publication ID', 1;

    DECLARE @lock int, @batch_id varchar(80), @staged_at datetime2(6);
    DECLARE @models TABLE (model_name varchar(64) PRIMARY KEY);
    INSERT @models VALUES ('dim_customer'), ('dim_product'), ('dim_supplier'), ('dim_warehouse'), ('dim_date'), ('fact_order'), ('fact_sales_line'), ('fact_payment'), ('fact_inventory'), ('fact_purchase'), ('mart_sales_daily'), ('mart_inventory_daily'), ('mart_order_quality_daily');

    BEGIN TRANSACTION;
    EXEC @lock = sys.sp_getapplock @Resource = N'retail_gold_publish',
        @LockMode = N'Exclusive', @LockOwner = N'Transaction', @LockTimeout = 30000;
    IF @lock < 0 THROW 51001, 'Could not acquire the retail publication lock', 1;
    IF EXISTS (SELECT 1 FROM report.publication_log WHERE publication_id = @publication_id)
    BEGIN
        COMMIT;
        RETURN;
    END;

    SELECT @batch_id = MIN(batch_id), @staged_at = MIN(staged_at_utc)
    FROM report_stage.model_manifest WHERE publication_id = @publication_id;

    IF EXISTS (
        SELECT model_name FROM @models
        EXCEPT
        SELECT model_name FROM report_stage.model_manifest WHERE publication_id = @publication_id
    ) OR EXISTS (
        SELECT model_name FROM report_stage.model_manifest WHERE publication_id = @publication_id
        EXCEPT
        SELECT model_name FROM @models
    ) OR EXISTS (
        SELECT 1 FROM report_stage.model_manifest WHERE publication_id = @publication_id
        AND (batch_id <> @batch_id OR staged_at_utc <> @staged_at)
    )
        THROW 51002, 'Publication manifest is incomplete or inconsistent', 1;

    IF EXISTS (
        SELECT 1
        FROM report_stage.model_manifest AS m
        LEFT JOIN (
            SELECT model_name, COUNT_BIG(*) AS row_count
            FROM report_stage.model_rows WHERE publication_id = @publication_id
            GROUP BY model_name
        ) AS r ON r.model_name = m.model_name
        WHERE m.publication_id = @publication_id AND m.expected_rows <> COALESCE(r.row_count, 0)
    ) OR EXISTS (
        SELECT model_name FROM report_stage.model_rows WHERE publication_id = @publication_id
        EXCEPT
        SELECT model_name FROM @models
    )
        THROW 51003, 'Staged row counts or model names do not match the manifest', 1;

    IF EXISTS (SELECT 1 FROM report.publication_log WHERE staged_at_utc > @staged_at)
        THROW 51004, 'A newer Gold snapshot is already published', 1;

    DELETE FROM report.dim_customer;
    INSERT report.dim_customer ([customer_key], [customer_id], [name], [city], [updated_at])
    SELECT [customer_key], [customer_id], [name], [city], [updated_at]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [customer_key] nvarchar(max) '$.customer_key',
        [customer_id] nvarchar(max) '$.customer_id',
        [name] nvarchar(max) '$.name',
        [city] nvarchar(max) '$.city',
        [updated_at] datetimeoffset(6) '$.updated_at'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'dim_customer';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'dim_customer')
        THROW 51005, 'Typed row count mismatch for dim_customer', 1;

    DELETE FROM report.dim_product;
    INSERT report.dim_product ([product_key], [product_id], [name], [category], [price], [currency], [updated_at])
    SELECT [product_key], [product_id], [name], [category], [price], [currency], [updated_at]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [product_key] nvarchar(max) '$.product_key',
        [product_id] nvarchar(max) '$.product_id',
        [name] nvarchar(max) '$.name',
        [category] nvarchar(max) '$.category',
        [price] decimal(18,2) '$.price',
        [currency] nvarchar(max) '$.currency',
        [updated_at] datetimeoffset(6) '$.updated_at'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'dim_product';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'dim_product')
        THROW 51005, 'Typed row count mismatch for dim_product', 1;

    DELETE FROM report.dim_supplier;
    INSERT report.dim_supplier ([supplier_id], [supplier_key])
    SELECT [supplier_id], [supplier_key]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [supplier_id] nvarchar(max) '$.supplier_id',
        [supplier_key] nvarchar(max) '$.supplier_key'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'dim_supplier';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'dim_supplier')
        THROW 51005, 'Typed row count mismatch for dim_supplier', 1;

    DELETE FROM report.dim_warehouse;
    INSERT report.dim_warehouse ([warehouse_id], [warehouse_key])
    SELECT [warehouse_id], [warehouse_key]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [warehouse_id] nvarchar(max) '$.warehouse_id',
        [warehouse_key] nvarchar(max) '$.warehouse_key'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'dim_warehouse';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'dim_warehouse')
        THROW 51005, 'Typed row count mismatch for dim_warehouse', 1;

    DELETE FROM report.dim_date;
    INSERT report.dim_date ([date], [date_key], [year], [quarter], [month], [day_of_month])
    SELECT [date], [date_key], [year], [quarter], [month], [day_of_month]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [date] date '$.date',
        [date_key] int '$.date_key',
        [year] int '$.year',
        [quarter] int '$.quarter',
        [month] int '$.month',
        [day_of_month] int '$.day_of_month'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'dim_date';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'dim_date')
        THROW 51005, 'Typed row count mismatch for dim_date', 1;

    DELETE FROM report.fact_order;
    INSERT report.fact_order ([order_id], [customer_key], [customer_id], [date_key], [order_date], [order_timestamp], [status], [has_customer], [is_completed], [processing_seconds], [order_currency], [line_total], [payment_total], [reconciliation_status], [reconciliation_difference])
    SELECT [order_id], [customer_key], [customer_id], [date_key], [order_date], [order_timestamp], [status], [has_customer], [is_completed], [processing_seconds], [order_currency], [line_total], [payment_total], [reconciliation_status], [reconciliation_difference]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [order_id] nvarchar(max) '$.order_id',
        [customer_key] nvarchar(max) '$.customer_key',
        [customer_id] nvarchar(max) '$.customer_id',
        [date_key] int '$.date_key',
        [order_date] date '$.order_date',
        [order_timestamp] datetimeoffset(6) '$.order_timestamp',
        [status] nvarchar(max) '$.status',
        [has_customer] bit '$.has_customer',
        [is_completed] bit '$.is_completed',
        [processing_seconds] bigint '$.processing_seconds',
        [order_currency] nvarchar(max) '$.order_currency',
        [line_total] decimal(38,2) '$.line_total',
        [payment_total] decimal(38,2) '$.payment_total',
        [reconciliation_status] nvarchar(max) '$.reconciliation_status',
        [reconciliation_difference] decimal(38,2) '$.reconciliation_difference'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'fact_order';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'fact_order')
        THROW 51005, 'Typed row count mismatch for fact_order', 1;

    DELETE FROM report.fact_sales_line;
    INSERT report.fact_sales_line ([order_item_id], [order_id], [product_key], [product_id], [customer_key], [date_key], [order_currency], [quantity], [unit_price], [line_amount], [has_order], [has_product])
    SELECT [order_item_id], [order_id], [product_key], [product_id], [customer_key], [date_key], [order_currency], [quantity], [unit_price], [line_amount], [has_order], [has_product]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [order_item_id] nvarchar(max) '$.order_item_id',
        [order_id] nvarchar(max) '$.order_id',
        [product_key] nvarchar(max) '$.product_key',
        [product_id] nvarchar(max) '$.product_id',
        [customer_key] nvarchar(max) '$.customer_key',
        [date_key] int '$.date_key',
        [order_currency] nvarchar(max) '$.order_currency',
        [quantity] int '$.quantity',
        [unit_price] decimal(18,2) '$.unit_price',
        [line_amount] decimal(29,2) '$.line_amount',
        [has_order] bit '$.has_order',
        [has_product] bit '$.has_product'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'fact_sales_line';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'fact_sales_line')
        THROW 51005, 'Typed row count mismatch for fact_sales_line', 1;

    DELETE FROM report.fact_payment;
    INSERT report.fact_payment ([payment_id], [order_id], [customer_key], [date_key], [amount], [currency], [method], [has_order])
    SELECT [payment_id], [order_id], [customer_key], [date_key], [amount], [currency], [method], [has_order]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [payment_id] nvarchar(max) '$.payment_id',
        [order_id] nvarchar(max) '$.order_id',
        [customer_key] nvarchar(max) '$.customer_key',
        [date_key] int '$.date_key',
        [amount] decimal(18,2) '$.amount',
        [currency] nvarchar(max) '$.currency',
        [method] nvarchar(max) '$.method',
        [has_order] bit '$.has_order'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'fact_payment';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'fact_payment')
        THROW 51005, 'Typed row count mismatch for fact_payment', 1;

    DELETE FROM report.fact_inventory;
    INSERT report.fact_inventory ([warehouse_key], [warehouse_id], [product_key], [product_id], [snapshot_date], [date_key], [on_hand], [stock_status], [has_product])
    SELECT [warehouse_key], [warehouse_id], [product_key], [product_id], [snapshot_date], [date_key], [on_hand], [stock_status], [has_product]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [warehouse_key] nvarchar(max) '$.warehouse_key',
        [warehouse_id] nvarchar(max) '$.warehouse_id',
        [product_key] nvarchar(max) '$.product_key',
        [product_id] nvarchar(max) '$.product_id',
        [snapshot_date] date '$.snapshot_date',
        [date_key] int '$.date_key',
        [on_hand] int '$.on_hand',
        [stock_status] nvarchar(max) '$.stock_status',
        [has_product] bit '$.has_product'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'fact_inventory';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'fact_inventory')
        THROW 51005, 'Typed row count mismatch for fact_inventory', 1;

    DELETE FROM report.fact_purchase;
    INSERT report.fact_purchase ([purchase_order_id], [supplier_key], [supplier_id], [product_key], [product_id], [purchase_date], [date_key], [quantity], [has_product])
    SELECT [purchase_order_id], [supplier_key], [supplier_id], [product_key], [product_id], [purchase_date], [date_key], [quantity], [has_product]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [purchase_order_id] nvarchar(max) '$.purchase_order_id',
        [supplier_key] nvarchar(max) '$.supplier_key',
        [supplier_id] nvarchar(max) '$.supplier_id',
        [product_key] nvarchar(max) '$.product_key',
        [product_id] nvarchar(max) '$.product_id',
        [purchase_date] date '$.purchase_date',
        [date_key] int '$.date_key',
        [quantity] int '$.quantity',
        [has_product] bit '$.has_product'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'fact_purchase';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'fact_purchase')
        THROW 51005, 'Typed row count mismatch for fact_purchase', 1;

    DELETE FROM report.mart_sales_daily;
    INSERT report.mart_sales_daily ([order_date], [order_currency], [completed_orders], [sales_amount], [payments_received], [orders_needing_review])
    SELECT [order_date], [order_currency], [completed_orders], [sales_amount], [payments_received], [orders_needing_review]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [order_date] date '$.order_date',
        [order_currency] nvarchar(max) '$.order_currency',
        [completed_orders] bigint '$.completed_orders',
        [sales_amount] decimal(38,2) '$.sales_amount',
        [payments_received] decimal(38,2) '$.payments_received',
        [orders_needing_review] bigint '$.orders_needing_review'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'mart_sales_daily';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'mart_sales_daily')
        THROW 51005, 'Typed row count mismatch for mart_sales_daily', 1;

    DELETE FROM report.mart_inventory_daily;
    INSERT report.mart_inventory_daily ([snapshot_date], [product_id], [units_on_hand], [warehouses_reporting], [warehouses_out_of_stock])
    SELECT [snapshot_date], [product_id], [units_on_hand], [warehouses_reporting], [warehouses_out_of_stock]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [snapshot_date] date '$.snapshot_date',
        [product_id] nvarchar(max) '$.product_id',
        [units_on_hand] bigint '$.units_on_hand',
        [warehouses_reporting] bigint '$.warehouses_reporting',
        [warehouses_out_of_stock] bigint '$.warehouses_out_of_stock'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'mart_inventory_daily';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'mart_inventory_daily')
        THROW 51005, 'Typed row count mismatch for mart_inventory_daily', 1;

    DELETE FROM report.mart_order_quality_daily;
    INSERT report.mart_order_quality_daily ([order_date], [reconciliation_status], [orders], [orders_missing_customer])
    SELECT [order_date], [reconciliation_status], [orders], [orders_missing_customer]
    FROM report_stage.model_rows AS s
    CROSS APPLY OPENJSON(s.row_json) WITH (
        [order_date] date '$.order_date',
        [reconciliation_status] nvarchar(max) '$.reconciliation_status',
        [orders] bigint '$.orders',
        [orders_missing_customer] bigint '$.orders_missing_customer'
    ) AS v
    WHERE s.publication_id = @publication_id AND s.model_name = 'mart_order_quality_daily';
    IF CONVERT(bigint, @@ROWCOUNT) <> (SELECT expected_rows FROM report_stage.model_manifest
        WHERE publication_id = @publication_id AND model_name = 'mart_order_quality_daily')
        THROW 51005, 'Typed row count mismatch for mart_order_quality_daily', 1;

    INSERT report.publication_log (publication_id, batch_id, staged_at_utc, published_at_utc)
    VALUES (@publication_id, @batch_id, @staged_at, SYSUTCDATETIME());

    DELETE FROM report_stage.model_rows WHERE publication_id = @publication_id;
    DELETE FROM report_stage.model_manifest WHERE publication_id = @publication_id;
    COMMIT;
END;
GO

IF DATABASE_PRINCIPAL_ID(N'retail_gold_stager') IS NULL CREATE ROLE retail_gold_stager;
IF DATABASE_PRINCIPAL_ID(N'retail_report_reader') IS NULL CREATE ROLE retail_report_reader;
GRANT SELECT, INSERT ON OBJECT::report_stage.model_rows TO retail_gold_stager;
GRANT SELECT, INSERT ON OBJECT::report_stage.model_manifest TO retail_gold_stager;
GRANT SELECT ON SCHEMA::report TO retail_report_reader;
-- Add the dedicated JDBC principal to retail_gold_stager and the BI identity to retail_report_reader.
-- For the ADF managed identity, provision its database user if needed, then grant:
-- GRANT EXECUTE ON OBJECT::report.publish_gold TO [adf-retail-de-261118];
