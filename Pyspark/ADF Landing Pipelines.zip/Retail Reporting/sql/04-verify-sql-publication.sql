-- Verify the last SQL publication and the default fixture.
SELECT TOP (1) publication_id, batch_id, published_at_utc
FROM report.publication_log ORDER BY published_at_utc DESC;
SELECT order_date, order_currency, completed_orders, sales_amount
FROM report.mart_sales_daily ORDER BY order_date, order_currency;
SELECT order_id, line_total, payment_total, reconciliation_status
FROM report.fact_order ORDER BY order_id;
SELECT customer_id, city FROM report.dim_customer WHERE customer_id = N'C001';
SELECT snapshot_date, product_id, units_on_hand
FROM report.mart_inventory_daily ORDER BY snapshot_date, product_id;
SELECT publication_id, model_name, expected_rows, staged_at_utc
FROM report_stage.model_manifest ORDER BY staged_at_utc DESC, model_name;
